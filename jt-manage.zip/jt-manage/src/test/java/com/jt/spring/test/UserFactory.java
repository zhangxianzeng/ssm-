package com.jt.spring.test;

import org.springframework.beans.factory.FactoryBean;
/**
 * 当容器启动时,当扫描到UserFacotry时,根据实现的接口,会自动的调用
 * getObject() 最终获取实例化对象.将实例化对象保存到Spring容器中
 * 通过依赖注入的形式,实现对象的注入
 * @author LYJ
 *
 */
public class UserFactory implements FactoryBean<String>{
	
	//表示获取工厂生成的实例化对象
	@Override
	public String getObject() throws Exception {
		//在该方法中,准备实例化对象
		//new User();
		return "1709班";
	}
	
	//表示对象的返回类型
	@Override
	public Class<?> getObjectType() {
		
		//return user.class
		return null;
	}
	
	//表示是否为单例对象
	@Override
	public boolean isSingleton() {
		// TODO Auto-generated method stub
		return false;
	}

}
