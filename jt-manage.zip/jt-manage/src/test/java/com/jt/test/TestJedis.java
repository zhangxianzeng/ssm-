package com.jt.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.springframework.data.redis.connection.PoolConfig;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisSentinelPool;
import redis.clients.jedis.JedisShardInfo;
import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

public class TestJedis {
	
	//测试redis操作
	//@Test
	public void test01(){
		/**
		 * 创建Jedis工具类 
		 * 参数说明
		 * 	host:表示redis的主机ip
		 *  port:表示redis的端口
		 */
		Jedis jedis = new Jedis("192.168.126.142", 6379);
		//向redis中插入数据
		jedis.set("tomcat", "tomcat猫");
		
		System.out.println(jedis.get("tomcat"));	
	}
	
	/**
	 * 参数说明:
	 * 	1.poolConfig 设置redis服务的配置工具类(例如设定最大连接数,最小空间数量)
	 *  2.shards  表示包含redis的节点的配置项List集合
	 * 	
	 * 思路:
	 * 	现在需要同时管理3台redis节点.首先应该定义redis的池.
	 * 在池中包含了很多redis的节点信息.如果需要操作redis
	 * 则先从池中获取某个节点的连接/通过该链接实现数据的新增和查询.
	 * 
	 * 1.定义连接池时需要设定池的大小(因为有默认值)
	 * 2.需要管理有哪些节点信息.
	 */
	//测试分片技术
	//@Test
	public void test02(){
		//JedisPoolConfig
		//定义redis的配置  poolConfig是过期类型 
		JedisPoolConfig poolConfig = new JedisPoolConfig();
		poolConfig.setMaxTotal(1000);//表示最大连接数
		poolConfig.setMinIdle(5);//最小空间数量
		//定义redis多个节点信息
		List<JedisShardInfo> list = 
				new ArrayList<JedisShardInfo>();
		//为集合添加参数
		list.add(new JedisShardInfo("192.168.126.142", 6379));
		list.add(new JedisShardInfo("192.168.126.142", 6380));
		list.add(new JedisShardInfo("192.168.126.142", 6381));
		//定义redis分片连接池
		ShardedJedisPool jedisPool = 
				new ShardedJedisPool(poolConfig, list);
		//获取连接操作redis
		ShardedJedis shardedJedis = jedisPool.getResource();
		System.out.println(shardedJedis.get("NUM_1"));
		//shardedJedis.set("tom", "tomcat猫");	//表示数据的赋值
		//System.out.println(shardedJedis.get("tom"));//从redis中获取数据	
		
		/*for(int i=1;i<20;i++){
			shardedJedis.set("NUM_"+i, ""+i);
		}*/
	}
	
	
	//哨兵jedis测试
	//@Test
	public void test03(){
		//2.定义哨兵set集合
		Set<String> sets = new HashSet<String>();
		
		//3.向集合中加入哨兵节点 192.168.126.142:26379
		sets.add(new HostAndPort("192.168.126.142",26379).toString());
		sets.add(new HostAndPort("192.168.126.142",26380).toString());
		sets.add(new HostAndPort("192.168.126.142",26381).toString());
		//1.定义哨兵连接池   参数编辑哨兵名称
		JedisSentinelPool sentinelPool = 
				new JedisSentinelPool("mymaster", sets);
		//4.插入数据
		 Jedis jedis = sentinelPool.getResource();
		 jedis.set("1709", "哨兵测试");
		 //5输出结果
		 System.out.println(jedis.get("1709"));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
