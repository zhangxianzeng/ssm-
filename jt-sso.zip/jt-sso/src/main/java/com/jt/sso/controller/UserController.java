package com.jt.sso.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jt.common.vo.SysResult;
import com.jt.sso.pojo.User;
import com.jt.sso.service.UserService;

import redis.clients.jedis.JedisCluster;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private JedisCluster jedisCluster;
	
	
	//校验用户的注册信息
	//url:http://sso.jt.com/user/check/admin123/1?callback=jsonp1517465570159&_=1517465578846
	//1 username、2 phone、3 email
	@RequestMapping("/check/{param}/{type}")
	@ResponseBody
	public Object checkUser(@PathVariable String param,@PathVariable Integer type,String callback){
		try {
			//根据传递的参数 判断数据是否存在
			Boolean result = userService.findCheckUser(param,type);
			//返回JSONP的数据
			MappingJacksonValue jacksonValue = 
					new MappingJacksonValue(SysResult.oK(result));
			//设定Callback参数
			jacksonValue.setJsonpFunction(callback);
			return jacksonValue;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}	
	}
	
	
	//用户的注册   http://sso.jt.com/user/register
	//Map<key:value>,,,,,<username,"tom">----这种思想是错的
	//通过HttpClient POST提交,将map中的数据封装为form表单的提交方式
	//form表单提交底层是通过二进制字节码的形式进行数据传输.
	@RequestMapping("/register")
	@ResponseBody
	public SysResult saveUser(User user){
		try {
			//用户的新增
			String username = userService.saveUser(user);
			return SysResult.oK(username);
		} catch (Exception e) {
			e.printStackTrace();
			return SysResult.build(201, "用户新增失败");
		}
	}
	
	
	/**
	 * @RequestParam作用:
	 * 	表示参数接收时采用 u的关键字获取.将获取到的value值交给
	 *  username属性
	 * @param username
	 * @param password
	 * @return
	 */
	//http://sso.jt.com/user/login
	@RequestMapping("/login")
	@ResponseBody  //形成的JSON数据 {status=201,msg="",data="null"}
	public SysResult doLogin(@RequestParam("u")String username,
			@RequestParam("p")String password){
		try {
			//获取ticket信息
			String ticket = userService.findUserByUP(username,password);
			return SysResult.oK(ticket);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return SysResult.build(201, "登录失败");
	}
	
	
	//根据ticket查询用户的JSON信息
	//http://sso.jt.com/user/query/" + _ticket  JSNP的提交
	@RequestMapping("/query/{ticket}")
	@ResponseBody
	public Object findUserByTicket(@PathVariable String ticket,
			String callback){
		//获取用户的JSON数据
		String userJSON = jedisCluster.get(ticket);
		
		MappingJacksonValue jacksonValue = 
				new MappingJacksonValue(SysResult.oK(userJSON));
		//设定返回的方法名称
		jacksonValue.setJsonpFunction(callback);
		
		return jacksonValue;
		
	}
	
	
	
	
	
	
	

}
