package com.jt.order.mapper;

import com.jt.common.mapper.SysMapper;
import com.jt.order.pojo.OrderItem;

public interface OrderItemMapper extends SysMapper<OrderItem>{

}
